﻿#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
//используется для увеличения экрана
#pragma comment(lib,"kernel32.lib")
#pragma comment(lib,"user32.lib")

using namespace std;

int main()
{
	setlocale(LC_ALL, "Russian");
	//разворачивает экран
	HWND hWnd = GetConsoleWindow();
	ShowWindow(hWnd, SW_MAXIMIZE);
	cout << "********************************************************************************";
	cout << "****************************** ***************** *******************************";
	cout << "**************************** ******************* ****************************";
	cout << "************************* ************************ *************************";
	cout << "********************** **************************** **********************";
	cout << "******************** ****************************** *******************";
	cout << "****************** ******************************** ****************";
	cout << "**************** ****** ** * * * ****** **************";
	cout << "************** ******* ** * *** * * * * * * ******* ************";
	cout << "************* ******* *** * ** * * * * * * ******** ***********";
	cout << "************ ******* *** * *** * * * * * * ******** ***********";
	cout << "*********** ******* ** * *** * * * * * * ******** **********";
	cout << "*********** ****** ** * *** * * * ******* **********";
	cout << "*********** * ********************************** * **********";
	cout << "*********** ** * ****************************** * ** ***********";
	cout << "************ ** * ***************************** ** ** ***********";
	cout << "************* * *** ** ******************************* ******* * ************";
	cout << "********************************************************************************";
	cout << "********************************************************************************";
	cout << "************************* *************************** *******************";
	cout << "**************************** *********************** **********************";
	cout << "******************************* ******************** ************************";
	cout << "********************************* ****************** **************************";
	cout << "******************** ************* **************** ************* **************";
	cout << "********************* ********** ************** ********** ***************";
	cout << "********************* ******* ************ ******* ***************";
	cout << "******************** ********** ********** ********** **************";
	cout << "******************** ****** **** ******** ***** ****** **************";
	cout << "********************* **** *************** **** ***************";
	cout << "*********************** ************* ******************";
	cout << "************************************ ********** ******************************";
	cout << "********************************************************************************";
	cout << "********************************************************************************";
	cout << "********************************************************************************";
	cout << "******************************* ********************** *************************";
	cout << "********************************* ****************** ****** ********************";
	cout << "************************** ******* **************** ******** *******************";
	cout << "************************* *** **** ************** ***** *** ******************";
	cout << "**************************** ********************* *********************";
	cout << "****************************** ******************* ***********************";
	cout << "****************** ************ ***************** *************************";
	cout << "***************** * ************ ***************** ************ *************";
	cout << "************** * *** ************* *************** ************* * * **********";

	cout << "*************** ***** ***** ********************************** *** **********";
	cout << "*************** ******* *** * ********************* ********** **** ***********";
	cout << "************************ * *** ******************* ********* *****************";
	cout << "************************* ***** ************ **** * ******* ******************";
	cout << "************************* ******* ********** * ** *** ***** *******************";
	cout << "************************* ******** ***** ** *** ***** *** ********************";
	cout << "*********************************** *** * **** ******** * *********************";
	cout << "************************************ * * *************** **********************";
	cout << "************************************* *** **************************************";
	cout << "************************************* ******************************************";
	cout << "********************************************************************************";
	cout << "********************************************************************************";
	cout << "********************************************************************************";
	cout << "********************************************************************************";
	cout << "********************************************************************************";
	Beep(300, 100);
	Beep(100, 100);
	Beep(300, 100);
	Beep(100, 300);
	Beep(300, 100);
	Beep(150, 100);
	Beep(300, 100);
	Beep(100, 100);
	Beep(300, 100);
	Beep(150, 300);
	Beep(350, 100);
	Beep(200, 100);
	Beep(250, 100);
	Beep(150, 100);
	Beep(350, 100);
	Beep(200, 300);
	Beep(300, 100);
	Beep(200, 100);
	Beep(300, 100);
	Beep(150, 100);
	Beep(300, 100);
	Beep(120, 300);
	Beep(300, 100);
	Beep(190, 100);
	Beep(300, 100);
	Beep(140, 100);
	Beep(300, 100);
	Beep(170, 300);
	Beep(360, 100);
	Beep(130, 100);
	Beep(300, 100);
	Beep(120, 100);
	Beep(300, 100);
	Beep(190, 300);
	Beep(300, 100);
	Beep(150, 100);
	Beep(300, 100);
	Beep(150, 100);
	Beep(300, 100);
	Beep(100, 300);
	Beep(150, 200);
	Beep(200, 200);
	Beep(250, 300);

	system("cls");

	int person, opponent, atk, asuccess, msuccess, game = 1, counter1 = 1, level = 1, atr, a, b, c = 0, d, decision, item;
	//Противник
	int attackop, defenseop, speedop, healthop = 100, opac, expo = 0, moneyo = 0;
	//Пользователь
	int magicus, attackus, defenseus, speedus, healthus = 100, exp = 0, money = 0, levelup = 200;

	//Имена
	string nameus, nameop;
	char exit;
	//Классы
	int healus = 0;
	do {
		cout << "(1)\n***************\nМастер:\n атака - 30\n защита - 40\n магия - 60\n скорость - 60\n***************" << endl << endl;
		cout << "(2)\n***************\nРыцарь:\n атака - 50\n защита - 75\n магия - 40\n скорость - 30\n***************" << endl << endl;
		cout << "(3)\n***************\nМагистр:\n атака - 60\n защита - 50\n магия - 30\n скорость - 50\n***************" << endl << endl;
		cout << "(4)\n***************\nБогатырь:\n атака - 40\n защита - 40\n магия - 50\n скорость - 65\n***************" << endl << endl;
		cout << "(5)\n***************\nГоблин:\n атака - 60\n защита - 65\n магия - 30\n скорость - 40\n***************" << endl << endl;
		cout << "(6)\n***************\nДемон:\n атака - 65\n защита - 70\n магия - 25\n скорость - 30\n***************" << endl << endl;
		cout << "Какого персонажа вы хотели бы выбрать?: ";
		cin >> person;
		if ((person > 6) && (person != 666))
		{
			system("cls");
			cout << "Вы должны ввести целое число от 1 до 6 !!!!\n\n";
			system("pause");
			system("cls");
		}
		if (person == 666)
		{
			system("cls");
			cout << "Муахахахаха !! Вы развязали сатану !!!";
			cout << "\n***************\nСатана\n атака - 100\n защита - 100\n магия - 100\n скорость - 100\n***************" << endl << endl;
			Beep(300, 200);
			Sleep(100);
			Beep(200, 200);
			Sleep(100);
			Beep(100, 200);
			Sleep(100);
			Beep(100, 100);
			Beep(125, 50);
			Beep(150, 50);
			Beep(125, 50);
			Beep(100, 200);
			system("pause");

			system("cls");
		}
	} while ((person > 6) && (person != 666));
	//информация для пользователя
	switch (person)
	{
	case 1:
		attackus = 30, defenseus = 40, magicus = 60, speedus = 60, nameus = "Мастер";
		break;
	case 2:
		attackus = 50, defenseus = 60, magicus = 40, speedus = 40, nameus = "Рыцарь";
		break;
	case 3:
		attackus = 60, defenseus = 50, magicus = 30, speedus = 50, nameus = "Магистр";
		break;
	case 4:
		attackus = 40, defenseus = 40, magicus = 50, speedus = 65, nameus = "Богатырь";
		break;
	case 5:
		attackus = 60, defenseus = 65, magicus = 30, speedus = 40, nameus = "Гоблин";
		break;
	case 6:
		attackus = 65, defenseus = 70, magicus = 30, speedus = 25, nameus = "Демон";
		break;
	case 666:
		attackus = 100, defenseus = 100, magicus = 100, speedus = 100, nameus = "Сатана";
		break;
	default:
		cout << "Никто";
	}
	do {
		do {
			system("cls");
			cout << "Привет, " << nameus << ", Чем бы Вы хотели заняться?\n\n";
			cout << "(1)\n**********\nИдти на Арену\n**********\n\n";
			cout << "(2)\n**********\nПерейти в Оружейную палату\n**********\n:";
			cin >> decision;
			switch (decision)
			{
			case 1:
				int random3, random4, random5;
				srand((unsigned)time(0));
				random3 = (rand() % 4) + 1;
				random4 = (rand() % 4) + 1;
				random5 = (rand() % 4) + 1;
				if (healthop == 0)
					healthop = 100;
				system("cls");
				do {
					cout << "Добро пожаловать на арену, " << nameus << ", с каким противником вы бы хотели сразиться?" << endl;
					d = (level * -1);
					switch (random3)
					{
					case 1:
						if (level <= 1)
						{
							cout << "(" << d + 2 << ")\n***************\nДерево(lvl 1):\n атака - 0\n защита - 20\n скорость - 0\n***************\n";
							cout << endl;
						}
						break;
					case 2:
						if (level <= 1)
						{
							cout << "(" << d + 2 << ")\n***************\nРак(lvl 1):\n атака - 0\n защита - 30\n скорость - 0\n***************\n";
							cout << endl;
						}
						break;
					case 3:
						if (level <= 1)
						{
							cout << "(" << d + 2 << ")\n***************\nБотlvl 1):\n атака - 0\n защита - 10\n скорость - 0\n***************\n";
							cout << endl;
						}
						break;
					case 4:
						if (level <= 1)
						{
							cout << "(" << d + 2 << ")\n***************\nБык(lvl 1):\n атака - 0\n защита - 5\n скорость - 0\n***************\n";
							cout << endl;
						}
						break;
					default:
						cout << "Не может случиться";
					}
					switch (random4)
					{
					case 1:
						if (level <= 2)
						{
							cout << "(" << d + 3 << ")\n***************\nРат(lvl 2):\n атака - 30\n защита - 20\n скорость - 30\n***************\n";
							cout << endl;
						}
						break;
					case 2:
						if (level <= 2)
						{
							cout << "(" << d + 3 << ")\n***************\nКот(lvl 2):\n атака - 40\n защита - 20\n скорость - 30\n***************\n";
							cout << endl;
						}
						break;
					case 3:
						if (level <= 2)
						{
							cout << "(" << d + 3 << ")\n***************\nСобака(lvl 2):\n атака - 45\n защита - 25\n скорость - 30\n***************\n";
							cout << endl;
						}
						break;
					case 4:
						if (level <= 2)
						{
							cout << "(" << d + 3 << ")\n***************\nЛетучая мышь(lvl 2):\n атака - 30\n защита - 20\n скорость - 35\n***************\n";
							cout << endl;
						}
						break;
					default:
						cout << "Не может случиться";
					}
					switch (random5)
					{
					case 1:
						if (level <= 3)
						{
							cout << "(" << d + 4 << ")\n***************\nМаг(lvl 3):\n атака - 65\n защита - 35\n скорость - 45\n***************\n";
							cout << endl;
						}
						break;
					case 2:
						if (level <= 3)
						{
							cout << "(" << d + 4 << ")\n***************\nШакал(lvl 3):\n атака - 60\n защита - 50\n скорость - 50\n***************\n";
							cout << endl;
						}
						break;
					case 3:
						if (level <= 3)
						{
							cout << "(" << d + 4 << ")\n***************\nКрестоносец(lvl 3):\n атака - 65\n защита - 55\n скорость - 45\n * **************\n";
								cout << endl;
						}
						break;
					case 4:
						if (level <= 3)
						{
							cout << "(" << d + 4 << ")\n***************\nВолк(lvl 3):\n атака - 55\n защита - 45\n скорость - 55\n***************\n";
							cout << endl;
						}
						break;
					default:
						cout << "Не может быть";
					}
					switch (random3)
					{
					case 1:
						if ((level <= 4) && (level >= 2))
						{
							cout << "(" << d + 5 << ")\n***************\nАссасин(lvl 4):\n атака - 75\n защита - 35\n скорость - 55\n***************\n";
							cout << endl;
						}
						break;
					case 2:
						if ((level <= 4) && (level >= 2))
						{
							cout << "(" << d + 5 << ")\n***************\nПакман(lvl 4):\n атака - 65\n защита - 30\n скорость - 60\n***************\n";
							cout << endl;
						}
						break;
					case 3:
						if ((level <= 4) && (level >= 2))
						{
							cout << "(" << d + 5 << ")\n***************\nЦыклоп(lvl 4):\n атака - 75\n защита - 35\n скорость - 55\n***************\n";
							cout << endl;
						}
						break;
					case 4:
						if ((level <= 4) && (level >= 2))
						{
							cout << "(" << d + 5 << ")\n***************\nВампир(lvl 4):\n атака - 70\n защита - 40\n скорость - 50\n***************\n";
							cout << endl;
						}
						break;
					default:
						cout << "Не может быть";
					}
					switch (random4)
					{
					case 1:
						if ((level <= 5) && (level >= 3))
						{
							cout << "(" << d + 6 << ")\n***************\nПойсейдон(lvl 5):\n атака - 80\n защита - 45\n скорость - 45\n***************\n";
							cout << endl;
						}
						break;
					case 2:
						if ((level <= 5) && (level >= 3))
						{
							cout << "(" << d + 6 << ")\n***************\nМинитавр(lvl 5):\n атака - 65\n защита - 55\n скорость - 50\n***************\n";
							cout << endl;
						}
						break;
					case 3:
						if ((level <= 5) && (level >= 3))
						{
							cout << "(" << d + 6 << ")\n***************\nКуклопс(lvl 5):\n атака - 75\n защита - 45\n скорость - 50\n***************\n";
							cout << endl;
						}
						break;
					case 4:
						if ((level <= 5) && (level >= 3))
						{
							cout << "(" << d + 6 << ")\n***************\nДракон(lvl 5):\n атака - 80\n защита - 55\n скорость - 30\n***************\n";
							cout << endl;
						}
						break;
					default:
						cout << "Не может быть";
					}
					switch (random4)
					{
					case 1:
						if ((level <= 6) && (level >= 4))
						{
							cout << "(" << d + 7 << ")\n***************\nАфина(lvl 6):\n атака - 85\n защита - 55\n скорость - 60\n***************\n";
							cout << endl;
						}
						break;
					case 2:
						if ((level <= 6) && (level >= 4))
						{
							cout << "(" << d + 7 << ")\n***************\nЗевс(lvl 6):\n атака - 90\n защита - 65\n скорость - 55\n***************\n";
							cout << endl;
						}
						break;
					case 3:
						if ((level <= 6) && (level >= 4))
						{
							cout << "(" << d + 7 << ")\n***************\nАид(lvl 6):\n атака - 75\n защита - 70\n скорость - 50\n***************\n";
							cout << endl;
						}
						break;
					case 4:
						if ((level <= 6) && (level >= 4))
						{
							cout << "(" << d + 7 << ")\n***************\nОсирис(lvl 6):\n атака - 70\n защита - 60\n скорость - 55\n***************\n";
							cout << endl;
						}
						break;
					default:
						cout << "Не может быть";
					}
					if ((level <= 99) && (level >= 5))
					{
						cout << "(" << d + 8 << ")\n***************\nБог(lvl ?):\n атака - ??\n защита - ??\n скорость - ??\n***************\n";
						cout << endl;
					}
					cout << ":";
					cin >> opponent;
					if ((opponent > 3) || (opponent < 1))
					{
						system("cls");
						cout << "Вы должны ввести целое число от 1 до 3 !!!\n\n";
						system("pause");
						system("cls");
					}
				} while ((opponent > 3) || (opponent < 1));
				system("cls");
				opponent = opponent + c;
				switch

					(opponent)
				{
				case 1:
					switch (random3)
					{
					case 1:
						attackop = 0, defenseop = 20, speedop = 0, nameop = "Дерево", expo = 40, moneyo = 20;
						break;
					case 2:
						attackop = 0, defenseop = 30, speedop = 0, nameop = "Рак", expo = 60, moneyo = 30;
						break;
					case 3:
						attackop = 0, defenseop = 10, speedop = 0, nameop = "Бот", expo = 20, moneyo = 10;
						break;
					case 4:
						attackop = 0, defenseop = 5, speedop = 0, nameop = "Книга", expo = 10, moneyo = 5;
						break;
					}
					break;
				case 2:
					switch (random4)
					{
					case 1:
						attackop = 30, defenseop = 20, speedop = 30, nameop = "Заяц", expo = 160, moneyo = 80;
						break;
					case 2:
						attackop = 40, defenseop = 20, speedop = 30, nameop = "Кот", expo = 180, moneyo = 90;
						break;
					case 3:
						attackop = 45, defenseop = 25, speedop = 30, nameop = "Собака", expo = 200, moneyo = 100;
						break;
					case 4:
						attackop = 35, defenseop = 20, speedop = 35, nameop = "Летучая мышь", expo = 180, moneyo = 90;
						break;
					}
					break;
				case 3:
					switch (random5)
					{
					case 1:
						attackop = 65, defenseop = 35, speedop = 45, nameop = "Маг", expo = 290, moneyo = 145;
						break;
					case 2:
						attackop = 60, defenseop = 50, speedop = 50, nameop = "Шакал", expo = 320, moneyo = 160;
						break;
					case 3:
						attackop = 65, defenseop = 55, speedop = 45, nameop = "Крестоносец", expo = 330, moneyo = 165;
						break;
					case 4:
						attackop = 55, defenseop = 45, speedop = 55, nameop = "Волк", expo = 310, moneyo = 155;
						break;
					}
					break;
				case 4:
					switch (random3)
					{
					case 1:
						attackop = 85, defenseop = 35, speedop = 65, nameop = "Ассасин", expo = 330, moneyo = 165;
						break;
					case 2:
						attackop = 75, defenseop = 30, speedop = 70, nameop = "Пакман", expo = 310, moneyo = 155;
						break;
					case 3:
						attackop = 85, defenseop = 35, speedop = 85, nameop = "Цыклоп", expo = 330, moneyo = 165;
						break;
					case 4:
						attackop = 80, defenseop = 40, speedop = 60, nameop = "Вампир", expo = 320, moneyo = 160;
						break;
					}

					break;
				case 5:
					switch (random4)
					{
					case 1:
						attackop = 90, defenseop = 45, speedop = 55, nameop = "Посейдон", expo = 340, moneyo = 170;
						break;
					case 2:
						attackop = 80, defenseop = 55, speedop = 60, nameop = "Минитавр", expo = 350, moneyo = 175;
						break;
					case 3:
						attackop = 85, defenseop = 45, speedop = 70, nameop = "Куклопс", expo = 340, moneyo = 170;
						break;
					case 4:
						attackop = 90, defenseop = 55, speedop = 45, nameop = "Дракон", expo = 340, moneyo = 170;
						break;
					}
					break;
				case 6:
					switch (random5)
					{
					case 1:
						attackop = 105, defenseop = 55, speedop = 70, nameop = "Афина", expo = 400, moneyo = 200;
						break;
					case 2:
						attackop = 110, defenseop = 65, speedop = 65, nameop = "Зевс", expo = 420, moneyo = 210;
						break;
					case 3:
						attackop = 95, defenseop = 70, speedop = 60, nameop = "Аид", expo = 390, moneyo = 195;
						break;
					case 4:
						attackop = 90, defenseop = 60, speedop = 65, nameop = "Осирис", expo = 370, moneyo = 185;
						break;
					}
					break;
				case 7:
					attackop = 110, defenseop = 90, speedop = 80, nameop = "Бог";
					break;
				default:
					cout << "Никто";
				}
				//степень успеха
				asuccess = speedus - defenseop + 50;
				msuccess = speedus - defenseop + 50;
				cout << "Первый раунд: " << nameus << " vs. " << nameop << "!!!";
				if (opponent != 7)
					Sleep(1000);
				if (opponent == 7)
				{
					Beep(350, 200);
					Beep(300, 300);
					Beep(400, 200);
					Beep(350, 250);
					Beep(400, 400);
					Beep(450, 600);
				}
				//последовательность нанесенного урона
				a = attackus - defenseop;
				b = magicus - defenseop;
				opac = 100 - defenseus;
				attackop = attackop - defenseus;
				if

					(attackop < 0)
					attackop = 0;
				else
					attackop = attackop;
				do {
					//Генератор случайных чисел
					int random, random2;
					random = rand() % 100;
					random2 = rand() % 100;


					system("CLS");

					//ограничения
					if (asuccess > 100)
						asuccess = 100;
					else
						asuccess = asuccess;
					if (msuccess > 100)
						msuccess = 100;
					else
						msuccess = msuccess;

					//доп.бонусные атаки
					do {
						if ((random < 80) && (random > 75))
						{
							system("cls");
							cout << "Невероятно .. мифический меч упал с неба тебе в кулак.\nВаша атака увеличилась еще на 5 очков! \ N (используется только в ЭТОМ раунде.)\n\n";
							a = a + 5;
							system("pause");
							system("cls");
						}
						if ((random < 76) && (random > 70))
						{
							system("cls");
							cout << "Вы только что вернулись из обувного магазина, в кроссовках быстрее молнии!\nВаша Скорость увеличилась еще на 5 пунктов! \ N (используется только в ЭТОМ раунде).\n\n";
							asuccess = asuccess + 5;
							msuccess = msuccess + 5;
							system("pause");
							system("cls");
						}
						if ((random < 71) && (random > 65))
						{
							system("cls");
							cout << "Древний волшебник посетил вас во сне и дал новое заклинание.\nВаша магия выросла еще на 5 очков! \ N (используется только в ЭТОМ раунде).\n\n";
							b = b + 5;
							system("pause");
							system("cls");
						}
						if ((random < 66) && (random > 60))
						{
							system("cls");
							cout << "Афина только что подарила вам новое прикрытие!\nВаша защита выросла еще на 5 очков!\n(используется только в ЭТОМ раунде.)\n\n";
							opac = opac - 5;
							system("pause");
							system("cls");
						}
						healus = attackop - 5;
						if (healus <= 0)
							healus = 10;
						cout << "Что бы вы хотели использовать?\n\n"
							<< "(1)\n***************\nатака: " << asuccess << "% шанс на успех\n***************\n\n"
							<< "(2)\n***************\nмагия: " << msuccess << "% шанс на успех\n***************\n\n"
							<< "(3)\n***************\nхил + " << healus << "здоровье\n***************\n\n";
						cout << ": ";
						cin >> atk;
						if (atk > 3)
						{
							system("cls");
							cout << "Вы ДОЛЖНЫ ввести число от 1 до 3 !!!\n\n";
							system("pause");
							system("cls");
						}
					} while (atk > 3);
					system("CLS");
					cout << "Расчет результатов";
					for (int counter = 0; counter <= 6; counter++)
					{
						Sleep(00);
						cout << ".";
					}
					system("CLS");
					switch (atk)
					{
					case 1:
						if (random <= asuccess)
						{
							if (random <= 10)
							{
								cout << "КРИТИЧНО !!!!\n\n\a";
								a = a * 2;
							}
							if (a < 0)
								a = 5;
							cout << "Ты забрал " << a << " очки здоровья от " << nameop << "!\n\n";
							healthop = healthop - a;
							if (healthop < 0)
								healthop = 0;
							cout << "В " << nameop << "'здоровье: " << healthop << endl << "Ваше здоровье: " << healthus << endl << endl;
							if (random <= 10)
								a = a / 2;
						}
						else
						{
							cout << "Вы пропустили!\n\n";
							cout << "В " << nameop << "'здоровье: " << healthop << endl << "Ваше здоровье: " << healthus << endl << endl;
						}
						break;
					case 2:
						if (random <= msuccess)
						{
							if (random <= 10)
							{
								cout << "КРИТИЧЕСКИЙ!!!!\n\n\a";
								b = b * 2;
							}
							if (b < 0)
								b = 5;
							cout << "Ты забрал " << b << " очки здоровья от " << nameop << "!\n\n";
							healthop = healthop - b;
							if (healthop < 0)
								healthop = 0;
							cout << "В " << nameop << "'здоровье: " << healthop << endl << "Ваше здоровье: " << healthus << endl << endl;
							if (random <= 10)
								b = b / 2;
						}
						else
						{
							cout << "Вы пропустили!\n\n";
							cout << "в " << nameop << "'здоровье: " << healthop << endl << "Ваше здоровье: " << healthus << endl << endl;
						}
						break;
					case 3:

						if (healthus < 100)
						{
							healthus = healthus + healus;
							cout << "Ваше здоровье выросло с " << healthus - healus << ", к " << healthus << "!!!" << endl << endl;
						}
						else
							cout << "Ваше здоровье уже 100%!!!" << endl << endl;
						break;
					default:
						cout << "Атака Недоступно";
					}
					system("pause");
					system("cls");
					if (healthop > 0)
					{
						cout << "Противник атакует";
						for (int counter = 6; counter >= 0; counter--)
						{
							Sleep(00);
							cout << ".";
						}
						system("cls");
						if (opac <= random2)
						{
							if (random2 <= 5)
							{
								cout << "КРИТИЧНО!!!!\n\n\a";
								attackop = attackop + 15;
							}
							if (attackop <= 0)
								attackop = 5;
							if (opponent == 1)
								attackop = 0;
							cout << "Противник забрал " << attackop << " очки здоровья от вас!\n\n";
							healthus = healthus - attackop;
							if (healthus < 0)
								healthus = 0;
							cout << "Здоровье соперника: " << healthop << endl << "Ваше здоровье: " << healthus << endl << endl;
							if (random2 <= 5)
								attackop = attackop - 15;
						}
						else
						{
							cout << "Противник промахнулся!\n\n";
							cout <<"Здоровье соперника: " << healthop << endl << "Ваше здоровье: " << healthus << endl << endl;
						}
						system("pause");
					}
				} while ((healthop >= 1) && (healthus >= 1));
				system("cls");
				if (healthop >= 1)
				{
					cout << "Вы были избиты " << nameop << "!!! Whhaaaahaahaaaaa\n\n";
					Beep(180, 500);
					Beep(160, 500);
					Beep(140, 500);
					Beep(120, 500);
					Beep(100, 800);
				}
				else if (opponent != 7)
				{
					if (healthus > 0)
					{
						healthus = 100;
						cout << "Вы получили " << expo << " опыт и " << moneyo << " $!!!\n\n";
						exp = exp + expo;
						money = money + moneyo;
						cout << "У вас есть " << exp << " очки опыта!\n";
						if (levelup > exp)
							cout << "Тебе нужно " << levelup - exp << " больше очков опыта для повышения уровня.\n";
						cout << "У вас есть $" << money << endl << endl;
						system("pause");
						system("cls");
					}

					if (exp >= levelup)  //Переход на новый уровень
					{
						c++;
						level++;
						cout << "Поздравляю с победой! Вы перешли на уровень " << level << "!!!.\n\n";
						cout << "Какой атрибут вы хотите увеличить на 5 пунктов?\n";
						cout << endl << "(1)\n*****\nатака\n*****\n\n(2)\n*****\nмагию\n*****\n\n(3)\n*****\nскорость\n*****\n\n(4)\n*****\nзащита\n*****\n:";
						cin >> atr;
						switch (atr)
						{
						case 1:
							attackus = attackus + 5;
							break;
						case 2:
							magicus = magicus + 5;
							break;
						case 3:
							speedus = speedus + 5;
							break;
						case 4:
							defenseus = defenseus + 5;
							break;
						default:
							defenseus = defenseus;
							break;
						}
						system("cls");
						cout << "Ваша текущая статистика:\nатака - " << attackus << endl << "магия - " << magicus << endl << "скорость - " << speedus << endl << "защита - " << defenseus << endl << endl;
						system("pause");
						system("cls");
						levelup = levelup * 2;
					}
				}
				system("pause");
				break;
			case 2: //доп. товар, который надо приобритать
				do {
					do {
						system("cls");
						cout << "У вас есть $" << money << " оставили.";
						cout << " Какой товар вы хотели бы купить?\n\n";
						cout << "(1)\n**********\nРжавый меч(+3 атака) - 300$\n**********\n";
						cout << "(2)\n**********\nСтальной меч(+6 атака) - 500$\n**********\n";
						cout << "(3)\n**********\nБольшой меч(+9 атака) - 700$\n**********\n\n";
						cout << "(4)\n**********\nДеревянный щит(+3 защита) - 300$\n**********\n";
						cout << "(5)\n**********\nМалый щит(+6 защита) - 500$\n**********\n";
						cout << "(6)\n**********\nЩит Гаурдиана(+9 защита) - 700$\n**********\n\n";
						cout << "(7)\n**********\nДеревянный Посох(+3 магия) - 300$\n**********\n";
						cout << "(8)\n**********\nИзогнутый посох(+6 магия) - 500$\n**********\n";

						cout << "(9)\n**********\nПосох чернокнижника(+9 магия) - 700$\n**********\n\n";
						cout << "(10)\n**********\nЛоферы с заплатками(+3 скорость) - 300$\n**********\n";
						cout << "(11)\n**********\nОбычные кроссовки(+6 скорость) - 500$\n**********\n";
						cout << "(12)\n**********\nБеговая обувь(+9 скорость) - 700$\n**********\n";
						cout << "(13)\n**********\nВыход\n**********\n";
						cin >> item;
						system("cls");
					} while ((item > 13) || (item < 1));
					switch (item)
					{
					case 1: //получение доп. товара и списание денег
						if (money >= 300)
						{
							cout << "Вы получили 3 атаки!\n\n";
							money = money - 300;
							attackus = attackus + 3;
							break;
						}
					case 2:
						if (money >= 500)
						{
							cout << "Вы получили 6 атаки!\n\n";
							money = money - 500;
							attackus = attackus + 6;
							break;
						}
					case 3:
						if (money >= 700)
						{
							cout << "Вы получили 9 атаки!\n\n";
							money = money - 700;
							attackus = attackus + 9;
							break;
						}
					case 4:
						if (money >= 300)
						{
							cout << "Вы получили 3 защиты!\n\n";
							money = money - 300;
							defenseus = defenseus + 3;
							break;
						}
					case 5:
						if (money >= 500)
						{
							cout << "Вы получили 6 защиты!\n\n";
							money = money - 500;
							defenseus = defenseus + 6;
							break;
						}
					case 6:
						if (money >= 700)
						{
							cout << "Вы получили 9 защиты!\n\n";
							money = money - 700;
							defenseus = defenseus + 9;
							break;
						}
					case 7:
						if (money >= 300)
						{
							cout << "Вы получили 3 магии!\n\n";
							money = money - 300;
							magicus = magicus + 3;
							break;
						}
					case 8:
						if (money >= 500)
						{
							cout << "Вы получили 6 магии!\n\n";
							money = money - 500;
							magicus = magicus + 6;
							break;
						}
					case 9:
						if (money >= 700)
						{
							cout << "Вы получили 9 магии!\n\n";
							money = money - 700;
							magicus = magicus + 9;
							break;
						}
					case 10:
						if (money >= 300)
						{
							cout << "Вы получили 3 скорости!\n\n";
							money = money - 300;
							speedus = speedus + 3;
							break;
						}
					case 11:
						if (money >= 500)
						{
							cout << "Вы набрали 3 скорости!\n\n";
							money = money - 500;
							speedus = speedus + 6;
							break;
						}
					case 12:
						if (money >= 700)
						{
							cout << "Вы набрали 3 скорости!\n\n";
							money = money - 700;
							speedus = speedus + 9;
							break;
						}
					default:
						speedus = speedus;
					}

					//Конец игры
					cout << "Вы хотите выйти? (да или нет): ";
					cin >> exit;

					system("cls");
				} while (exit != 'да');
				break;
			default:
				cout << "Пожалуйста, выберите 1 или 2 !!!";
			}
		} while ((healthus > 0) && (opponent != 7));
	} while ((healthus >= 1) && (opponent != 7));
	if (healthus >= 1)
	{
		cout << "МОЙ БОГ!! ТЫ ВЫИГРАЛ!!! Ты лучше бога ... поздравляюВ!\n";
		cout << " ******** ";
		cout << " ************ ** ";
		cout << " ************** ****** ";
		cout << " *********************** ";
		cout << " *********************** ";
		cout << " **************** ***** ";
		cout << " ************** *** ";
		cout << " ************ * ";
		cout << " ******** *** * * ";
		cout << " **** * * * ";
		cout << " ** * * * ";
		cout << " **** * * * ";
		cout <<" * ";
		cout << " * ";
		cout << " * * * ";
		cout << " * * * ";
		cout << " * * * ";
		cout << " * ";
		cout << " * ";
		cout << " * ";
		Beep(100, 100);
		Beep(120, 100);
		Beep(140, 100);
		Beep(160, 100);
		Beep(180, 100);
		Beep(200, 100);
		Beep(220, 100);
		Beep(240, 100);
		Beep(260, 100);
		Beep(280, 100);
		Beep(300, 100);
		Beep(320, 100);
		Beep(340, 100);
		Beep(360, 100);
		Beep(380, 100);
		Beep(400, 100);
		Beep(420, 100);
		Beep(440, 100);
		Beep(460, 100);
		Beep(480, 100);
		Beep(500, 100);
		Beep(600, 300);
	}
}

